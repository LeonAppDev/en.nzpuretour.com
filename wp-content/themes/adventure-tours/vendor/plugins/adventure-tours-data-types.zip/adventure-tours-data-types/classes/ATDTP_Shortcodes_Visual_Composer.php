<?php
/**
 * Visual Composer plugin integration helper.
 *
 * @author    Themedelight
 * @package   Themedelight/ATDTP
 * @version   2.0.0
 */

class ATDTP_Shortcodes_Visual_Composer
{
	public $shortcodes_category_name = 'Adventure Tours';

	public $shortcode_templates_prefix = 'Adventure Tours - ';

	/**
	 * @var ATDTP_Shortcodes_VC_Content_Normilizer
	 */
	public $content_normilizer;

	/**
	 * @var ATDTP_Shortcodes_Helper
	 */
	public $shortcodes_helper;

	private $inited = false;

	public function __construct() {
		add_filter( 'vc_before_init', array( $this, 'init' ), 15 );
	}

	public function get_schortcodes_helper() {
		if ( ! $this->shortcodes_helper ) {
			$this->shortcodes_helper = ATDTP()->shortcodes_helper();
		}
		return $this->shortcodes_helper;
	}

	public function init() {
		if ( $this->inited ) {
			return false;
		}

		$this->inited = true;

		if ( is_admin() ) {
			$normalizer_config = array(
				'normilize_mode_active' => true,
				'replacement_mode_active' => $this->get_schortcodes_helper()->is_shortcode_registered( 'row' ),
			);

			if ( !empty( $normalizer_config['replacement_mode_active'] ) || !empty( $normalizer_config['normilize_mode_active'] ) ) {
				ATDTP()->require_file( '/classes/ATDTP_Shortcodes_VC_Content_Normilizer.php' );
				$this->content_normilizer = new ATDTP_Shortcodes_VC_Content_Normilizer( $normalizer_config );
			}
		}

		$this->register_shortcode_params();
		$this->register_shortcodes();

		add_action( 'vc_load_default_templates_action', array( $this, 'add_page_tamplates' ) );

		return true;
	}

	protected function register_shortcode_params() {
		add_shortcode_param(
			'attach_image_url',
			array( $this, 'shortcode_param_attach_image_url' ),
			ATDTP()->get_plugin_url() . '/assets/js/visual-composer-shortcode-param-attach-image-url.js'
		);
	}

	protected function register_shortcodes() {
		$config = $this->get_schortcodes_helper()->get_shortcodes_config();

		foreach ( $config as $schorcode_name => $sc_config ) {
			$params = array();

			if ( !empty( $sc_config['params'] ) ) {
				foreach ( $sc_config['params'] as $_param_name => $_param ) {
					$_param['heading'] = $_param['param_name'] = $_param_name;
					if ( empty( $_param['type'] ) ) {
						$_param['type'] = 'textfield';
					}
					if ( !empty( $_param['value'] ) && !isset( $_param['save_always'] ) ) {
						$_param['save_always'] = true;
					}
					$params[] = $_param;
				}
			}

			$sc_config['base'] = $schorcode_name;
			$sc_config['category'] = $this->shortcodes_category_name;
			$sc_config['params'] = $params;

			vc_map( $sc_config );
		}
	}

	public function shortcode_param_attach_image_url( $settings, $value ) {
		$output = '';
		$output .= '<style>' .
			'#attach-image-url{overflow:hidden;}' .
			'#attach-image-url .attach-image-url__storage{width:80%; float:left}' .
			'#attach-image-url .attach-image-url__add-img{height:36px;width:20%; float:right}' .
		'</style>';

		$additional_classes = $settings['param_name'] . ' ' . $settings['type'];

		$output .= '<div id="attach-image-url">' .
			'<input type="text" class="wpb_vc_param_value attach-image-url__storage ' . esc_attr( $additional_classes ) . '" name="' . esc_attr( $settings['param_name'] ) . '" value="' . esc_url( $value ) . '"/>' .
			'<button class="attach-image-url__add-img">' . esc_html__( 'Select image', 'adventure-tours-data-types' ) . '</button>' .
		'</div>';

		return $output;
	}

	public function add_page_tamplates() {
		$helper = $this->get_schortcodes_helper();
		vc_add_default_templates( array(
			'name' => $this->shortcode_templates_prefix . esc_html__( 'Home page', 'adventure-tours-data-types' ),
			'content' => $helper->render_view( 'templates/vc-pages/home' ),
		) );

		vc_add_default_templates( array(
			'name' => $this->shortcode_templates_prefix . esc_html__( 'Contact page', 'adventure-tours-data-types' ),
			'content' => $helper->render_view( 'templates/vc-pages/contact' ),
		) );
	}
}
